<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';

$adminCount = (int) db()->query('SELECT COUNT(*) FROM admins')->fetchColumn();
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = (string) ($_POST['action'] ?? '');

    if ($action === 'setup' && $adminCount === 0) {
        $username = trim((string) ($_POST['username'] ?? ''));
        $password = (string) ($_POST['password'] ?? '');

        if (strlen($username) < 3 || strlen($password) < 8) {
            $error = 'Username কমপক্ষে ৩ অক্ষর এবং password কমপক্ষে ৮ অক্ষর দিন।';
        } else {
            $statement = db()->prepare('INSERT INTO admins (username, password) VALUES (?, ?)');
            $statement->execute([$username, password_hash($password, PASSWORD_DEFAULT)]);
            flash('success', 'Admin account তৈরি হয়েছে। এখন login করুন।');
            redirect('index.php');
        }
    } elseif ($action === 'login') {
        if (attempt_admin_login(trim((string) ($_POST['username'] ?? '')), (string) ($_POST['password'] ?? ''))) {
            redirect('index.php');
        }
        $error = 'Username অথবা password সঠিক নয়।';
    }
}

if (!is_admin_logged_in()) {
    ?>
    <!doctype html>
    <html lang="bn">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?= $adminCount === 0 ? 'প্রথম Admin তৈরি' : 'Admin Login' ?></title>
        <link rel="stylesheet" href="../assets/css/style.css">
    </head>
    <body class="auth-body">
        <section class="auth-card">
            <a class="brand brand-center" href="../"><span class="brand-mark">H</span><span>Hosting Admin</span></a>
            <?php if ($adminCount === 0): ?>
                <p class="eyebrow">ONE-TIME SETUP</p>
                <h1>প্রথম Admin তৈরি করুন</h1>
                <p class="muted">এটি শুধু প্রথমবার দেখা যাবে। Admin তৈরি হওয়ার পর login screen আসবে।</p>
                <form method="post" class="stack">
                    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                    <input type="hidden" name="action" value="setup">
                    <label>Admin username<input name="username" required minlength="3" autocomplete="username"></label>
                    <label>Admin password<input type="password" name="password" required minlength="8" autocomplete="new-password"></label>
                    <?php if ($error !== ''): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>
                    <button class="button button-primary" type="submit">Admin তৈরি করুন</button>
                </form>
            <?php else: ?>
                <p class="eyebrow">SECURE ACCESS</p>
                <h1>Admin Login</h1>
                <p class="muted">আপনার control panel-এ প্রবেশ করুন।</p>
                <form method="post" class="stack">
                    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                    <input type="hidden" name="action" value="login">
                    <label>Username<input name="username" required autocomplete="username"></label>
                    <label>Password<input type="password" name="password" required autocomplete="current-password"></label>
                    <?php if ($error !== ''): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>
                    <button class="button button-primary" type="submit">Login</button>
                </form>
            <?php endif; ?>
        </section>
    </body>
    </html>
    <?php
    exit;
}

$total = (int) db()->query('SELECT COUNT(*) FROM users')->fetchColumn();
$active = (int) db()->query('SELECT COUNT(*) FROM users WHERE status = 1 AND (expiry_date IS NULL OR expiry_date >= NOW())')->fetchColumn();
$banned = (int) db()->query('SELECT COUNT(*) FROM users WHERE status = 0')->fetchColumn();
$expired = (int) db()->query('SELECT COUNT(*) FROM users WHERE expiry_date IS NOT NULL AND expiry_date < NOW()')->fetchColumn();
admin_page_start('Dashboard', 'dashboard');
?>
<section class="stats-grid">
    <article class="stat-card"><span>Total users</span><strong><?= $total ?></strong><small>All registered keys</small></article>
    <article class="stat-card accent"><span>Active users</span><strong><?= $active ?></strong><small>Allowed to connect</small></article>
    <article class="stat-card"><span>Banned users</span><strong><?= $banned ?></strong><small>Blocked accounts</small></article>
    <article class="stat-card"><span>Expired users</span><strong><?= $expired ?></strong><small>Past expiry date</small></article>
</section>
<section class="panel-grid">
    <article class="panel">
        <div class="panel-heading"><div><p class="eyebrow">SYSTEM</p><h2>Server status</h2></div><span class="status-dot"><i></i> Online</span></div>
        <div class="detail-list">
            <div><span>PHP version</span><strong><?= e(PHP_VERSION) ?></strong></div>
            <div><span>Database</span><strong>MySQL / PDO</strong></div>
            <div><span>App version</span><strong><?= e(setting('app_version', '1.0.0')) ?></strong></div>
        </div>
    </article>
    <article class="panel">
        <div class="panel-heading"><div><p class="eyebrow">QUICK ACTION</p><h2>Manage access</h2></div></div>
        <p class="muted">নতুন key তৈরি করুন, HWID সেট করুন অথবা existing user block করুন।</p>
        <a class="button button-primary" href="users.php">Users খুলুন</a>
    </article>
</section>
<?php admin_page_end(); ?>