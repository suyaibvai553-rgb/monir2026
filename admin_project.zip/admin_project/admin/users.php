<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = (string) ($_POST['action'] ?? '');

    try {
        if ($action === 'create') {
            $username = trim((string) ($_POST['username'] ?? ''));
            $hwid = trim((string) ($_POST['hwid'] ?? ''));
            $publicKey = trim((string) ($_POST['public_key'] ?? ''));
            $expiry = trim((string) ($_POST['expiry_date'] ?? ''));
            if ($username === '' || $hwid === '') {
                throw new RuntimeException('Username/key এবং HWID দুটিই দিতে হবে।');
            }
            $statement = db()->prepare('INSERT INTO users (username, hwid, public_key, expiry_date) VALUES (?, ?, ?, ?)');
            $statement->execute([$username, $hwid, $publicKey !== '' ? $publicKey : null, $expiry !== '' ? $expiry : null]);
            flash('success', 'নতুন user তৈরি হয়েছে।');
        } elseif ($action === 'toggle') {
            $id = (int) ($_POST['id'] ?? 0);
            $statement = db()->prepare('UPDATE users SET status = IF(status = 1, 0, 1) WHERE id = ?');
            $statement->execute([$id]);
            flash('success', 'User status পরিবর্তন হয়েছে।');
        } elseif ($action === 'delete') {
            $id = (int) ($_POST['id'] ?? 0);
            $statement = db()->prepare('DELETE FROM users WHERE id = ?');
            $statement->execute([$id]);
            flash('success', 'User delete হয়েছে।');
        } elseif ($action === 'update') {
            $id = (int) ($_POST['id'] ?? 0);
            $hwid = trim((string) ($_POST['hwid'] ?? ''));
            $publicKey = trim((string) ($_POST['public_key'] ?? ''));
            $expiry = trim((string) ($_POST['expiry_date'] ?? ''));
            $statement = db()->prepare('UPDATE users SET hwid = ?, public_key = ?, expiry_date = ? WHERE id = ?');
            $statement->execute([$hwid, $publicKey !== '' ? $publicKey : null, $expiry !== '' ? $expiry : null, $id]);
            flash('success', 'User তথ্য update হয়েছে।');
        }
    } catch (Throwable $exception) {
        flash('error', $exception instanceof RuntimeException ? $exception->getMessage() : 'কাজটি করা যায়নি। Username/HWID duplicate হতে পারে।');
    }
    redirect('users.php');
}

$users = db()->query('SELECT * FROM users ORDER BY id DESC')->fetchAll();
admin_page_start('Users', 'users');
?>
<section class="panel">
    <div class="panel-heading"><div><p class="eyebrow">ACCESS CONTROL</p><h2>নতুন user/key যোগ করুন</h2></div></div>
    <form method="post" class="form-grid">
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
        <input type="hidden" name="action" value="create">
        <label>Username / Key<input name="username" required maxlength="50" placeholder="যেমন: user001"></label>
        <label>HWID<input name="hwid" required maxlength="100" placeholder="Android device HWID"></label>
        <label>Public key <span class="optional">(optional)</span><input name="public_key" maxlength="100"></label>
        <label>Expiry date <span class="optional">(optional)</span><input type="datetime-local" name="expiry_date"></label>
        <div class="form-actions"><button class="button button-primary" type="submit">User যোগ করুন</button></div>
    </form>
</section>
<section class="panel">
    <div class="panel-heading"><div><p class="eyebrow">REGISTERED ACCESS</p><h2>User list</h2></div><span class="count-badge"><?= count($users) ?> users</span></div>
    <?php if (!$users): ?>
        <div class="empty-state"><strong>এখনো কোনো user নেই</strong><span>উপরের form দিয়ে প্রথম user তৈরি করুন।</span></div>
    <?php else: ?>
        <div class="table-wrap">
            <table>
                <thead><tr><th>ID</th><th>Username / Key</th><th>HWID</th><th>Status</th><th>Expiry</th><th>Actions</th></tr></thead>
                <tbody>
                <?php foreach ($users as $user): ?>
                    <?php $isActive = (int) $user['status'] === 1 && !is_expired($user['expiry_date']); ?>
                    <tr>
                        <td>#<?= (int) $user['id'] ?></td>
                        <td><strong><?= e($user['username']) ?></strong><small><?= e($user['public_key'] ?? '') ?></small></td>
                        <td><code><?= e($user['hwid']) ?></code></td>
                        <td><span class="pill pill-<?= $isActive ? 'success' : 'danger' ?>"><?= $isActive ? 'Active' : ((int) $user['status'] === 0 ? 'Banned' : 'Expired') ?></span></td>
                        <td><?= $user['expiry_date'] ? e($user['expiry_date']) : 'No expiry' ?></td>
                        <td class="actions">
                            <form method="post"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= (int) $user['id'] ?>"><button class="button button-small button-ghost" type="submit"><?= $isActive ? 'Ban' : 'Activate' ?></button></form>
                            <form method="post" data-confirm="এই user delete করবেন?"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int) $user['id'] ?>"><button class="button button-small button-danger" type="submit">Delete</button></form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</section>
<?php admin_page_end(); ?>