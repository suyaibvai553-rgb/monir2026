<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    save_setting('app_version', valid_version(trim((string) ($_POST['app_version'] ?? '1.0.0'))));
    save_setting('update_url', trim((string) ($_POST['update_url'] ?? '')));
    save_setting('maintenance_mode', isset($_POST['maintenance_mode']) ? '1' : '0');
    save_setting('apk_hash', trim((string) ($_POST['apk_hash'] ?? '')));
    flash('success', 'Settings save হয়েছে।');
    redirect('settings.php');
}

admin_page_start('Settings', 'settings');
?>
<section class="panel narrow-panel">
    <div class="panel-heading"><div><p class="eyebrow">APP CONFIGURATION</p><h2>Update ও security settings</h2></div></div>
    <form method="post" class="stack">
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
        <label>Current app version<input name="app_version" value="<?= e(setting('app_version', '1.0.0')) ?>" pattern="\d+(\.\d+){0,3}" required></label>
        <label>Update download URL <span class="optional">(optional)</span><input type="url" name="update_url" value="<?= e(setting('update_url')) ?>" placeholder="https://example.com/app.apk"></label>
        <label>Expected APK hash <span class="optional">(optional)</span><input name="apk_hash" value="<?= e(setting('apk_hash')) ?>" placeholder="SHA-256 hash"></label>
        <label class="check-label"><input type="checkbox" name="maintenance_mode" value="1" <?= setting('maintenance_mode') === '1' ? 'checked' : '' ?>> Maintenance mode চালু রাখুন</label>
        <button class="button button-primary" type="submit">Settings save করুন</button>
    </form>
</section>
<section class="panel narrow-panel">
    <div class="panel-heading"><div><p class="eyebrow">ANDROID ENDPOINTS</p><h2>অ্যাপে বসানোর link</h2></div></div>
    <div class="endpoint-list">
        <div><span>Login</span><code><?= e((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http') . '://' . ($_SERVER['HTTP_HOST'] ?? 'YOUR_DOMAIN.com')) ?>/api/connect.php</code></div>
        <div><span>Update</span><code><?= e((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http') . '://' . ($_SERVER['HTTP_HOST'] ?? 'YOUR_DOMAIN.com')) ?>/api/update.php</code></div>
        <div><span>APK hash</span><code><?= e((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http') . '://' . ($_SERVER['HTTP_HOST'] ?? 'YOUR_DOMAIN.com')) ?>/api/apkhash.php</code></div>
    </div>
</section>
<?php admin_page_end(); ?>