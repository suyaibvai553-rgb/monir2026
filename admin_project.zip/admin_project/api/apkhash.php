<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['status' => false, 'message' => 'POST method required'], 405);
}

$input = request_json();
$hash = trim((string) ($input['hash'] ?? ''));
$expectedHash = trim(setting('apk_hash'));

if ($hash === '') {
    json_response(['status' => false, 'message' => 'Missing hash'], 422);
}

if ($expectedHash === '') {
    json_response([
        'status' => true,
        'verified' => false,
        'message' => 'Hash verification is not configured',
    ]);
}

json_response([
    'status' => true,
    'verified' => hash_equals(strtolower($expectedHash), strtolower($hash)),
    'message' => hash_equals(strtolower($expectedHash), strtolower($hash)) ? 'Hash verified' : 'Hash mismatch',
]);