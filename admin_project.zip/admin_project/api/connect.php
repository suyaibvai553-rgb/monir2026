<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['status' => false, 'message' => 'POST method required'], 405);
}

if (setting('maintenance_mode') === '1') {
    json_response(['status' => false, 'message' => 'System is under maintenance']);
}

$input = request_json();
$game = trim((string) ($input['game'] ?? ''));
$key = trim((string) ($input['key'] ?? ''));
$hwid = trim((string) ($input['hwid'] ?? ''));
$publicKey = trim((string) ($input['publicKey'] ?? ''));

if ($key === '' || $hwid === '') {
    json_response(['status' => false, 'message' => 'Missing key or hwid'], 422);
}

$statement = db()->prepare('SELECT id, username, hwid, public_key, status, expiry_date FROM users WHERE username = ? AND hwid = ? LIMIT 1');
$statement->execute([$key, $hwid]);
$user = $statement->fetch();

if (!is_array($user) || (int) $user['status'] !== 1) {
    json_response(['status' => false, 'message' => 'Invalid credentials']);
}

if (is_expired($user['expiry_date'])) {
    json_response(['status' => false, 'message' => 'Access expired']);
}

if ($user['public_key'] !== null && $user['public_key'] !== '' && $publicKey !== '' && !hash_equals((string) $user['public_key'], $publicKey)) {
    json_response(['status' => false, 'message' => 'Public key mismatch']);
}

json_response([
    'status' => true,
    'message' => 'Login Success',
    'game' => $game,
    'auth' => [
        'message' => base64_encode('Success'),
        'token_access' => $publicKey,
        'username' => $user['username'],
        'expiry_date' => $user['expiry_date'],
    ],
]);