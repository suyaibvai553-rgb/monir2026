<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/functions.php';

$clientVersion = valid_version(trim((string) ($_GET['version'] ?? '0.0.0')));
$latestVersion = valid_version(setting('app_version', '1.0.0'));
$updateUrl = setting('update_url');
$needsUpdate = version_compare($clientVersion, $latestVersion, '<');

json_response([
    'status' => true,
    'update_required' => $needsUpdate,
    'current_version' => $clientVersion,
    'latest_version' => $latestVersion,
    'update_url' => $updateUrl,
    'maintenance_mode' => setting('maintenance_mode') === '1',
]);