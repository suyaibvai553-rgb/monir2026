<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';

function e(?string $value): string
{
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

function redirect(string $location): never
{
    header('Location: ' . $location);
    exit;
}

function flash(string $type, string $message): void
{
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function take_flash(): ?array
{
    $message = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return is_array($message) ? $message : null;
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verify_csrf(): void
{
    $provided = (string) ($_POST['csrf_token'] ?? '');
    $stored = (string) ($_SESSION['csrf_token'] ?? '');

    if ($stored === '' || $provided === '' || !hash_equals($stored, $provided)) {
        http_response_code(419);
        exit('Invalid request token. Please go back and try again.');
    }
}

function setting(string $key, string $default = ''): string
{
    $statement = db()->prepare('SELECT `value` FROM settings WHERE `key` = ? LIMIT 1');
    $statement->execute([$key]);
    $value = $statement->fetchColumn();
    return $value === false ? $default : (string) $value;
}

function save_setting(string $key, string $value): void
{
    $statement = db()->prepare(
        'INSERT INTO settings (`key`, `value`) VALUES (?, ?)
         ON DUPLICATE KEY UPDATE `value` = VALUES(`value`)'
    );
    $statement->execute([$key, $value]);
}

function json_response(array $payload, int $status = 200): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function request_json(): array
{
    $raw = file_get_contents('php://input');
    if ($raw === false || trim($raw) === '') {
        return [];
    }

    $decoded = json_decode($raw, true);
    return is_array($decoded) ? $decoded : [];
}

function is_expired(?string $expiryDate): bool
{
    return $expiryDate !== null && $expiryDate !== '' && strtotime($expiryDate) < time();
}

function valid_version(string $version): string
{
    return preg_match('/^\d+(?:\.\d+){0,3}$/', $version) === 1 ? $version : '0.0.0';
}

function admin_page_start(string $title, string $active = ''): void
{
    $flash = take_flash();
    ?>
    <!doctype html>
    <html lang="bn">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?= e($title) ?> | Hosting Admin</title>
        <link rel="stylesheet" href="../assets/css/style.css">
    </head>
    <body class="admin-body">
        <div class="admin-shell">
            <aside class="sidebar">
                <a class="brand" href="index.php"><span class="brand-mark">H</span><span>Hosting Admin</span></a>
                <nav class="nav">
                    <a class="<?= $active === 'dashboard' ? 'active' : '' ?>" href="index.php">Dashboard</a>
                    <a class="<?= $active === 'users' ? 'active' : '' ?>" href="users.php">Users</a>
                    <a class="<?= $active === 'settings' ? 'active' : '' ?>" href="settings.php">Settings</a>
                    <a href="logout.php">Logout</a>
                </nav>
            </aside>
            <main class="main-content">
                <header class="topbar">
                    <div>
                        <p class="eyebrow">CONTROL PANEL</p>
                        <h1><?= e($title) ?></h1>
                    </div>
                    <a class="button button-ghost" href="logout.php">Logout</a>
                </header>
                <?php if ($flash !== null): ?>
                    <div class="alert alert-<?= e($flash['type']) ?>"><?= e($flash['message']) ?></div>
                <?php endif; ?>
    <?php
}

function admin_page_end(): void
{
    ?>
            </main>
        </div>
        <script src="../assets/js/app.js"></script>
    </body>
    </html>
    <?php
}