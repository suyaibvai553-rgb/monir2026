<?php
declare(strict_types=1);

/*
 * Copy this project to your PHP hosting and replace these four values.
 * Keep this file outside the public web root when your hosting allows it.
 */
const DB_HOST = 'sql101.infinityfree.com';
const DB_NAME = 'if0_42653538_freefire';
const DB_USER = 'if0_42653538';
const DB_PASS = 'CfUIqLzGInn';
const DB_CHARSET = 'utf8mb4';

date_default_timezone_set('Asia/Dhaka');

function db(): PDO
{
    static $pdo = null;

    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;

    try {
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
    } catch (PDOException $exception) {
        error_log('Hosting project database connection failed: ' . $exception->getMessage());
        http_response_code(500);
        exit('Database connection failed. Check includes/config.php.');
    }

    return $pdo;
}